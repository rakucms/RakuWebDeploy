﻿
var reisize = false;

var resizeX, resizeY;

//original portlet width,height
var resizeTemp1, resizeTemp2;

//var className;

var resizePortletName;
var resizePortletInstance;

var resizePortlet;

var resizeContent;

var resizeTitle;

var resizeDivObj = null;

function resizeMove(e) 
{

    var e = (!e) ? window.event : e; //IE:Moz
    
    try 
    {

        var clientX;
        var clientY;

        if (window.event != null) 
        {
            clientX = e.clientX;
            clientY = e.clientY;

            if (reisize == true) 
            {
                resizePortlet.style.width = resizeTemp1 + clientX - resizeX+'px';
                resizePortlet.style.height = resizeTemp2 + clientY - resizeY + 'px';
                
                //resizeContent.style.width = resizeTemp1 + clientX - resizeX;
                resizeContent.style.height = resizeTemp2 + clientY - resizeY + 'px';
                //resizeTitle.style.width = resizeTemp1 + clientX - resizeX;

            }
        }
        else 
        {
            clientX = parseInt(e.pageX);
            clientY = parseInt(e.pageY);

            if (reisize == true) 
            {
                resizePortlet.style.width = parseInt(resizeTemp1) + parseInt(clientX) - parseInt(resizeX) + 'px';
                resizePortlet.style.height = parseInt(resizeTemp2) + parseInt(clientY) - parseInt(resizeY) + 'px';
                
                //resizeContent.style.width = parseInt(resizeTemp1) + parseInt(clientX) - parseInt(resizeX);
                resizeContent.style.height = parseInt(resizeTemp2) + parseInt(clientY) - parseInt(resizeY) + 'px';
                //resizeTitle.style.width = parseInt(resizeTemp1) + parseInt(clientX) - parseInt(resizeX);
            }
        }
    }
    catch (e)
	{ }

	try {
	    e.cancelBubble = true;
	    e.returnValue = false;
	}
	catch (e) {
	    //firefox
	    e.stopPropagation();
	    e.returnValue = false;
	}    
}

function resizeMouseup(e) 
{

    var e = (!e) ? window.event : e; //IE:Moz
    
    try 
    {

        reisize = false;
        document.onmouseup = null;
        document.onmousemove = null;
        //resizeTitle.className = className;

        //record portlet layout height and width		

        var saveObj = document.getElementById("Portlet_Selection");
        var position;

        try {
            saveObj.load("PortletPosition");

            var objstatus = saveObj.getAttribute(resizePortletName + "__" + resizePortletInstance);

            position = objstatus.split('|');

            //alert(objstatus);

        }
        catch (e) {
            window.status = e.Description;
            //position[0]="";
            //position[1]="";
        }

        if (position != null && position != "undefined")
            saveObj.setAttribute(resizePortletName + "__" + resizePortletInstance, position[0] + "|" + resizePortlet.style.width + "," + resizeContent.style.height);
        else
            saveObj.setAttribute(resizePortletName + "__" + resizePortletInstance, "," + "|" + resizePortlet.style.width + "," + resizeContent.style.height);

        var oTimeNow = new Date(); // Start Time
        oTimeNow.setMinutes(oTimeNow.getMinutes() + 5);
        var sExpirationDate = oTimeNow.toUTCString();
        saveObj.expires = sExpirationDate;

        saveObj.save("PortletPosition");

    }
    catch (e)
	{ }

	try 
	{
	    e.cancelBubble = true;
	    e.returnValue = false;
	}
	catch (e) 
	{
	    //firefox
	    e.stopPropagation();
	    e.returnValue = false;
	}

    //should check when width or height doesnot change ,no need to call this method
	RecordPortletLayout("resize");
	
	window.status = "Resize Done";
}

//e for firefox event object
function resizeDrags(e, PortletID, ContentBlockID, TitleBlockID, name, instance) {

    var e = (!e) ? window.event : e; //IE:Moz

    resizePortlet = document.getElementById(PortletID);
    resizeContent = document.getElementById(ContentBlockID);
    resizeTitle = document.getElementById(TitleBlockID);
    resizePortletName = name;
    resizePortletInstance = instance;

    //event.cancelBubble = true;
    window.status = "Start Resize";

    document.body.onselectstart = "return false";
    
    document.onmousemove = resizeMove;
    document.onmouseup = resizeMouseup;
    resizePortlet.style.position = "relative";


    try 
    {

        reisize = true;

        if (window.event != null) 
        {
            resizeX = window.event.clientX;
            resizeY = window.event.clientY;

            resizeTemp1 = resizePortlet.style.pixelWidth;
            resizeTemp2 = resizeContent.style.pixelHeight - 5;
        }
        else 
        {
            resizeX = parseInt(e.pageX);
            resizeY = parseInt(e.pageY);

            resizeTemp1 = parseInt(resizePortlet.style.width);
            resizeTemp2 = parseInt(resizeContent.style.height) - 5;
        }



        //className = title.className;
    }
    catch (e) 
    {
        //window.status=e.message;
    }

    try 
    {
        e.cancelBubble = true;
        e.returnValue = false;
    }
    catch (e) {
        //firefox
        e.stopPropagation();
        e.returnValue = false;
    }    
}