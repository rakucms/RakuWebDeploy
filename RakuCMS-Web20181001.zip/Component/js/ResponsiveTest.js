﻿
$(document).ready(function ()
{
    var previewpath = window.location.href;
    var screenSize = "";
    var oritentation = "portraint";
    var divPos = $("#frameContainer");

    //latest width and height of resizable div element
    var currentW;
    var currentH;

    //initial width and height of resizable div element
    var originalW = $("#frameContainer").css("width");
    var originalH = $("#frameContainer").css("height");

    $("#frameContainer").resizable({

        alsoResize: "#contentIframe",
        stop: function (event, ui)
        {
            if (oritentation == "portraint") {
                currentW = $(this).css("width");
                currentH = $(this).css("height");
            }
            else {
                currentW = $(this).css("height");
                currentH = $(this).css("width");
            }
        }
        ,
        resize: function (event, ui) {
            var pos = Math.ceil($(this).width()) + "x" + Math.ceil($(this).height());
            $("#pixelHint").text(pos);
        }
        /*,
        start: function (event, ui) {         
            //originalW = $(this).css("width");
            //originalH = $(this).css("height");
        }*/
    });

    $("#contentIframe").attr("src", "./");

    $("#viewportUL li").click(function () {

        var current = $(this);

        currentW = null;
        currentH = null;

        $("#frameContainer").css("display", "table");
 
        var selectedTitle = $(this).attr("title");
        
        if (selectedTitle == "desktop") {

            location.reload(previewpath);
            
            return;
        }
        else {
            screenSize = selectedTitle.split("x"); 

            if (oritentation == "portraint") {
                $("#contentIframe").css("width", screenSize[0] + "px");
                $("#contentIframe").css("height", screenSize[1] + "px");

                //reset position
                if (originalW != null && originalH != null) {

                    $("#frameContainer").css("width", originalW);
                    $("#frameContainer").css("height", originalH);
                }
                else {
                    $("#frameContainer").css("width", screenSize[0] + "px");
                    $("#frameContainer").css("height", screenSize[1] + "px");
                }
            }
            else {

                $("#contentIframe").css("width", screenSize[1] + "px");
                $("#contentIframe").css("height", screenSize[0] + "px");
              
                if (originalW != null) 
                {
                    $("#frameContainer").css("width", originalW);
                    $("#frameContainer").css("height", originalH);
                }
                else {
                    $("#frameContainer").css("width", screenSize[1] + "px");
                    $("#frameContainer").css("height", screenSize[0] + "px");
                }
            }
        }

        resetViewPort(current);

        var headhtml = $("head").html(); 
        var srchtml = $("#LayoutDIV").html();
         
        //var htmlstr = "<html><head>" + headhtml + "</head><body>" + srchtml + "</body></html>";
        //$("#contentIframe").contents().find("html").html(htmlstr);
        $("#contentIframe").contents().find("body").html(srchtml);
        $("#LayoutDIV").css("display", "none");


        $("#pixelHint").text(selectedTitle);

    });

    $("#orientationUL li").click(function () {

        var current = $(this);
        resetOrientation(current);

        oritentation = $(this).attr("title"); 
        
        if (oritentation == "portraint") {

            if (currentW == null && currentH == null)
            {

                $("#contentIframe").css("width", screenSize[0] + "px");
                $("#contentIframe").css("height", screenSize[1] + "px");
            }
            else {
                $("#contentIframe").css("width", currentW );
                $("#contentIframe").css("height", currentH);
            }
        }
        else {

            if (currentW == null && currentH == null)
            {
                $("#contentIframe").css("width", screenSize[1] + "px");
                $("#contentIframe").css("height", screenSize[0] + "px");
            }
            else {
                $("#contentIframe").css("width", currentH);
                $("#contentIframe").css("height", currentW);
            }
        }

        $("#frameContainer").css("width", $("#contentIframe").css("width"));
        $("#frameContainer").css("height", $("#contentIframe").css("height"));
    });

});


function resetViewPort(current) {
    listItems = $("#viewportUL").find("li").each(function () {
        $(this).attr("class", "listhorizontal");
    });

    current.attr("class", "selectedlisthorizontal");
}

function resetOrientation(current) {
    listItems = $("#orientationUL").find("li").each(function () {
        $(this).attr("class", "listhorizontal");
    });

    current.attr("class", "selectedlisthorizontal");
}