﻿
function useService(postStr, postBody) 
{

    try {
        if (postStr != '') 
        {

            var xmlDoc = new ActiveXObject("MSXML.DOMDocument");
            xmlDoc.async = false;
            
            var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            xmlHttp.open("post", postStr, false);
            xmlHttp.send(postBody);

            xmlDoc.load(xmlHttp.responseXml);

            var portletHTML = "";
            if (xmlDoc.parseError.errorCode == 0)		//parse OK
            {

                portletHTML = xmlDoc.documentElement.selectSingleNode("//div").text;

            }
            else {
                return "";
            }


            delete xmlDoc;
            delete xmlHttp;

            return portletHTML;

        }
        else {
            return "";
        }
    }
    catch (e) {
        return "";
    }
}			