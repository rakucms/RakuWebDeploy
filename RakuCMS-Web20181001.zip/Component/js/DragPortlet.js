﻿//******************************************************
//* Drag portlet javscript
//* Date : 2010/12/1
//* Update : move behavior to js 
//******************************************************

var portlet;

var dragapproved;

var divObj;

var portletHost;

var PortletName;

var Instance;

var LastWidth;

var LastHeight;

var LastZIndex;

var LastBackground;

var lastStyle;

var currentContainer;

var x;

var y;

var moved;

var temp1;

var temp2;

var layoutDesignMode;
var siteKey;
var viewConfig;
var allowMultiInstance;
var newCloneObj;
var selectedPortletID;
var selectedBRStyle = "2px solid green";

//for copy and paste
var selectedPageName;

function SetDesignMode(page,mode) 
{
    layoutDesignMode = mode;
    selectedPageName = page;

    //get cookie to set leftpanel status 
    var leftPnaelStatus = getCookie('LeftPanel');
    ToggleLeftPane(leftPnaelStatus);

    //get cookie to display current edited portlet property window
    var lastPage = getCookie('SelectedPage');

    if (page == lastPage && mode != 'layoutrandom') {
        var portlet = getCookie('SelectedPortletName');
        var instance = getCookie('SelectedPortletInstance');
        if(portlet!=null)
            DisplayPortletProperty(portlet, instance);
    }
    
}

function move(e) 
{

    var e = (!e) ? window.event : e; //IE:Moz
    
    var offsetX;
    var offsetY = 15;
      
    if (dragapproved == "true") 
    {

        var clientX;
        var clientY;

        try {

            if (e.type === "mousemove") {
                var event = e;
            } else {
                var event = e.changedTouches[0];
            }

            e.preventDefault();

            clientX = event.clientX;
            clientY = event.clientY;

            portlet.style.eIndex = "1001";

            portlet.style.left = event.pageX - x + "px";
            portlet.style.top =  event.pageY - y + "px";

            //portlet.style.left = temp1 + clientX - x + 'px';
            //portlet.style.top = temp2 + clientY - y + 'px';

        }
        catch (exp) {

        }

        window.status = "Moving..";
                                 
        //check if can drop to target element
        {
            
            portlet.style.left = parseInt(temp1) + parseInt(clientX) - x;
            portlet.style.top = parseInt(temp2) + parseInt(clientY) - y;
            
            //if (parseInt(clientY) - parseInt(pos) >= 1) 
            {

                var obj = document.elementFromPoint(clientX, e.clientY - offsetY);
                if (obj != null && obj.className == "DropTD" && dragapproved == "true") 
                {
                    window.status = "Can Drop Here";                 

                    lastStyle = portlet.style.border;
                    currentContainer = obj;
                    $(".DropTD").css("border", lastStyle);
                    obj.style.border = selectedBRStyle;
                }
                else 
                {
                    window.status = "";
                }
            }
        }
        
    }

    try 
    {
        e.cancelBubble = true;
        e.returnValue = false;
    }
    catch (e) 
    {
        //firefox
        e.stopPropagation();
        e.returnValue = false;
    }
    return false;
}

function mouseup(e) 
{

    var offsetY;   
    var posX;
    var posY;

    var e = (!e) ? window.event : e; //IE:Moz

    if (window.event != null)
    {
        posX = e.clientX;
        posY = e.clientY;
        //offsetY = parseInt(e.offsetY) + parseInt("1");
        offsetY = 15;
    }
    else 
    {
        posX = e.pageX;
        posY = e.pageY;
        //offsetY = parseInt(e.layerY) + parseInt("1");
        offsetY = 15;
    }

    e.cancelBubble = true;
    
    //display portlet attribure
    //DisplayPortletProperty(PortletName, Instance);
    DisplayDefaultProperty(PortletName, Instance);
    
    //if same position with before moving then no action
    if (moved == posY) 
    {
        window.status = "";
        document.onmouseup = null;
        document.onmousemove = null;
        
        return;
    }
    
    var obj = document.elementFromPoint(posX, posY - offsetY);

    var windURL = window.location.href;

    if (windURL.indexOf("?") != -1) {
        windURL = windURL.substring(0, windURL.indexOf("?"));
    }

    //parse current request url
    var siteURL = window.location.href;
    if (siteURL.indexOf("?") != -1) 
    {
        siteURL = siteURL.substring(0, siteURL.indexOf("?"));
    }

    if (selectedPortletID!=null && selectedPortletID != "") 
    {
        //create clone portlet
        var cloneObj = document.createElement("DIV");

        cloneObj.innerHTML = portlet.innerHTML;
        cloneObj.id = selectedPortletID;
        cloneObj.setAttribute("class", portlet.getAttribute("class"));
        cloneObj.style.width = portlet.style.width;
        cloneObj.style.zIndex = portlet.style.zIndex;
        //cloneObj.style.left = portlet.style.left;

        var portletParent;

        if (portlet.parentElement)
            portletParent = portlet.parentElement;
        else
            portletParent = portlet.parentNode;

        portletParent.appendChild(cloneObj);

        selectedPortletID = "";
    }
    
    try 
    {
        
        if ((obj.className == "DropTD" && dragapproved == "true") || currentContainer !=null)
        {
            
            var id = portlet.id;
            var div = document.createElement("div");

            var cloneDIV = document.createElement("div");
            
            if (layoutDesignMode == "layouttable" && Instance == "") {
                var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=layout&PortletName=" + PortletName + "&Instance=" + Instance + "&Preview=true";
                var result = useService(postStr, "");
                //alert(result);
                div.innerHTML = result;
            }
            else if (layoutDesignMode == "customize" && Instance == "") {
                var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=min&PortletName=" + PortletName + "&Instance=" + Instance + "&Preview=true";
                var result = useService(postStr, "");

                div.innerHTML = result;
            }
            else {
                div.innerHTML = cloneDIV.appendChild(portlet.cloneNode(true)).parentNode.innerHTML;
            }
            div.style.zIndex = portlet.style.zIndex;

            if (obj.className == "DropTD")
                obj.appendChild(div);
            else
                currentContainer.appendChild(div);

            var collect = div.getElementsByTagName("div");

            for (var i = 0; i < collect.length; i++) {
                if (collect[i].id == id) {
                    collect[i].style.position = "relative";
                    collect[i].style.left = "0";
                    collect[i].style.top = "0";
                    break;
                }
            }

            var parent;

            if (portlet.parentElement)
                parent = portlet.parentElement;
            else
                parent = portlet.parentNode;

            parent.removeChild(portlet); //remove original portlet from td element
            //======drop done=====

            //=====record the portlet list and order
            //RecordPortletListOrder();

        }/*
        else if (obj.className == "DisableTD" && Instance == "") 
        {
            var id = portlet.id;
            var div = document.createElement("div");

            var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=min&PortletName=" + PortletName + "&Instance=" + Instance + "&Preview=true";
            var result = useService(postStr, "");

            div.innerHTML = result;

            div.style.zIndex = portlet.style.zIndex;

            div.style.position = "absolute";
            div.style.left = posX;
            div.style.top = posY;

            obj.appendChild(div);

            var parent;

            if (portlet.parentElement)
                parent = portlet.parentElement;
            else
                parent = portlet.parentNode;

            parent.removeChild(portlet); //remove original portlet from td element
            //======drop done=====

            //=====record the portlet list and order
            //RecordPortletListOrder();
            //=====

        }*/
        else if (layoutDesignMode == "layoutrandom" && Instance == "") 
        {
      
            var id = portlet.id;
            var div = document.createElement("div");
                 
            var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=layout&PortletName=" + PortletName + "&Instance=" + Instance + "&Preview=true";
            var result = useService(postStr, "");
            
            div.innerHTML = result;

            div.style.zIndex = portlet.style.zIndex;

            div.style.position = "absolute";
            div.style.left = posX;
            div.style.top = posY;

            obj.appendChild(div);

            var parent;

            if (portlet.parentElement)
                parent = portlet.parentElement;
            else
                parent = portlet.parentNode;
            
            parent.removeChild(portlet); //remove original portlet from td element
            //======drop done=====
            
            //=====record the portlet list and order
            //RecordPortletListOrder();
            //=====
        
        }
        else if (obj.className == "DropListTD" && dragapproved == "true")  // zone under all portlet list 
        {

            var id = portlet.id;
            var div = document.createElement("div");

            var cloneDIV = document.createElement("div");

            if (Instance != "") {
                var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=min&PortletName=" + PortletName + "&Instance=" + Instance + "&Preview=true";

                var result = useService(postStr, "");
                div.innerHTML = result;
            }
            else
                div.innerHTML = cloneDIV.appendChild(portlet.cloneNode(true)).parentNode.innerHTML;

            div.style.zIndex = portlet.style.zIndex;
            obj.appendChild(div);

            //div.style.position = "relative";
            //div.style.left = "0";
            //div.style.top  = "0";

            var collect = div.getElementsByTagName("div");

            for (var i = 0; i < collect.length; i++) {
                if (collect[i].id == id) {
                    collect[i].style.position = "relative";
                    collect[i].style.left = "0";
                    collect[i].style.top = "0";
                    break;
                }
            }

            var parent;

            if (portlet.parentElement)
                parent = portlet.parentElement;
            else
                parent = portlet.parentNode;

            parent.removeChild(portlet); //remove original portlet from td element
            //======drop done=====

            //=====record the portlet list and order
            //RecordPortletListOrder();
            //=====

        }

        //=====record the portlet list and order
        RecordPortletListOrder();
        //
    }
    catch (e) 
    {
        window.status = e.message;
        alert(e.message);
    }
    
    //in edit mode track new added portlet and save portlet configuration to page preview config
    
    if (layoutDesignMode != null ) 
    {
        var postStr = siteURL+"?Target=~/Component/PortletListService.aspx&OrderList=" + escape(document.getElementById("OrderList").value)+"&Preview=true&EditAdmin=true";
        var result = useService(postStr, "");
    }
    
    dragapproved = "false";
    document.onmouseup = null;
    document.onmousemove = null;

    try 
    {
        e.cancelBubble = true;
        e.returnValue = false;
    }
    catch (e) 
    {
        //firefox
        e.stopPropagation();
        e.returnValue = false;
    }

    RecordPortletLayout("move");
    
    PortletName = null;
    Instance = null; 
    currentContainer = null;

    window.status = "Move Done";

    //restore border style
    $(".DropTD").css("border", lastStyle);
   
}

//record all portlet order inside container
function RecordPortletListOrder() 
{

    //get portlet layout list and order			
    //iterate all talbes to find layout container
    var TBList = document.body.getElementsByTagName("div");
    var order = "";
    var i = 0;
    var layoutTable;

    var orderList = "";
    var tbNbr = 0;

    try 
    {
        for (var t = 0; t < TBList.length; t++) 
        {
            //get current layout, portlet order list

            var layoutContainer = TBList[t].getAttribute("LayoutContainer");

            //if (TBList[t].className == "DropTD" || TBList[t].className == "DisableTD")
            if (layoutContainer != null && layoutContainer=="true")
            {
                order = "";
                layoutTable = TBList[t];

                var port = layoutTable.getElementsByTagName("span");

                if (port.length) 
                {
                    for (var j = 0; j < port.length; j++) 
                    {
                        if (port[j].getAttribute("name") == "PortletName")
                            order = order + port[j].getAttribute("PortletName") + "~";
                    }
                }
                else 
                {
                    order = order + "" + "~";
                }

                order = order.substring(0, order.length - 1);
                order = order + "^";

                order = order.substring(0, order.length - 1);
                orderList = orderList + tbNbr + ":" + order + "|";
                tbNbr++;
            }

        }

        if (orderList != "" && orderList.length > 1)
            orderList = orderList.substring(0, orderList.length - 1);

        //set order to form element
        //alert(orderList);
        document.getElementById("OrderList").value = orderList;

    }
    catch (e) 
    {
            alert("Errro to record order : " + e.message)
    }

    //test to save portlet by ajax
    //var postStr = "Component/EditPortlet.aspxSiteKey=" + siteKey + "&ViewConfig=" + viewConfig + "&PortletName=" + PortletName + "&Instance=" + Instance+"^";
    //var result = useService(postStr, "");
}

//record all portlet position 
function RecordPortletLayout(resizeFlag) 
{
    
    var i = 0;
    var j = 0;
    var _portletName = "";
    var positionList = "";

    try 
    {
                    
        //iterate all talbes to find layout table
        var port = document.body.getElementsByTagName("div");

        if (port.length) 
        {
            for (i = 0; i < port.length; i++) 
            {
                if (port[i].className == "PortLetContainer") 
                {
                    _portletName = "";
                    var spanlist = port[i].getElementsByTagName("span");

                    if (spanlist.length) {
                        for (j = 0; j < spanlist.length; j++) 
                        {
                            if (spanlist[j].getAttribute("name") == "PortletName") 
                            {
                                _portletName = spanlist[j].getAttribute("PortletName");

                                break;
                            }
                        }
                    }
                            
                    if (resizeFlag == "resize") 
                    {
                        positionList = positionList + _portletName + "~" + port[i].style.left + "," + port[i].style.top + "|" + port[i].style.width + "," + port[i].style.height + "^";
                    }
                            
                    if (resizeFlag == "move") 
                    {
                        positionList = positionList + _portletName + "~" + port[i].style.left + "," + port[i].style.top + "|" + "" + "," + "" + "^";
                    }
                }
            }
        }
                    
        if (positionList != "" && positionList.length > 1)
            positionList = positionList.substring(0, positionList.length - 1);

        //alert(positionList);
        document.getElementById("PortletPositionList").value = positionList;
    }
    catch (e)
    { alert("Errro to record order : " + e.message) }

}

function dragObject(e,PortletID, AllowInstance, ppName, ppInstance,ppFrom) 
{
    
    var e = (!e) ? window.event : e; //IE:Moz
    
    PortletName = ppName;
    Instance = ppInstance;
    portletHost = ppFrom;
  
    //current drag object	
    portlet = document.getElementById(PortletID);
    
    divObj = null;

    window.status = "Start Move";

    //change border style when selected
    //portlet.style.border = "1px dotted #3d74b1";
    
    document.body.onselectstart = "return false";
    document.onmouseup = mouseup;
    document.onmousemove = move;
    dragapproved = "true";
        

    //set zIndex to max
    try 
    {
        divObj = document.getElementById("MaxIndex");
    }
    catch (e)
    {}

    if (divObj == null) 
    {

        divObj = document.createElement("DIV");
        divObj.style.display = "none";
        divObj.id = "MaxIndex";
        divObj.setAttribute("Index", "6666");
        document.body.insertBefore(divObj,null);
    }
    
    var zind = divObj.getAttribute("Index");
    portlet.style.zIndex = parseInt(zind) + 1;
    divObj.setAttribute("Index", parseInt(zind) + 1);
    
    //get start position value   
    {
        if (e.type === "mousedown") {
            var event = e;
        } else {
            var event = e.changedTouches[0];
        }
   
        //same across browsers 
        x = parseInt(event.pageX);
        y = parseInt(event.pageY);

        temp1 = portlet.style.left;
        temp2 = portlet.style.top;

        //in firefox must be set left and top in style otherwsie cannot get value
        /*
        if (temp1 == "")
            temp1 = 0;

        if (temp2 == "")
            temp2 = 0;
        */
    }

    moved = y;

    //clone selected portlet whihc allow multi instance
    if (AllowInstance == "multi" && ppFrom == "site") 
    {
        selectedPortletID = PortletID;
        //newCloneObj = parent.$('#' + PortletID).clone();
        //newCloneObj.appendTo($('#' + PortletID).parent());
    }
    else 
    {    
        portlet.onselectstart = "return false";
    }

    //set property container url to reflect portlet property list
    //DisplayPortletProperty(PortletName, ppInstance);

    try 
    {
        e.cancelBubble = true;
        e.returnValue = false;
    }
    catch (e) 
    {
        //firefox
        e.stopPropagation();
        e.returnValue = false;
    }    
}

//clone current selected portlet
function cloneObject(e, PortletID, AllowInstance, ppName, ppInstance, ppFrom) 
{

    //parse current request url
    var siteURL = window.location.href;
    if (siteURL.indexOf("?") != -1) 
    {
        siteURL = siteURL.substring(0, siteURL.indexOf("?"));
    }
     
    //current drag object	
    portlet = document.getElementById(PortletID);
    
    if ((ppFrom == "page" && AllowInstance == "multi") || ppFrom == "site")
    //if ((ppFrom == "page" && AllowInstance == "multi"))
    {

        if (!window.confirm("Clone current widget ?"))
            return;

        //create clone portlet
        var cloneObj = document.createElement("div");
        var postStr = siteURL + "?Target=~/Component/PortletAjaxService.aspx&Mode=xml&ActionMode=clone&PortletName=" + ppName + "&Instance=" + ppInstance + "&Preview=true";
        var result = useService(postStr, "");
        
        cloneObj.innerHTML = result;

        var portletParent;
        if (portlet.parentElement)
            portletParent = portlet.parentElement;
        else
            portletParent = portlet.parentNode;

        portletParent.appendChild(cloneObj);

        //=====record the portlet list and order
        //RecordPortletListOrder();
        //var postStr = siteURL + "?Target=/Component/PortletListService.aspx&OrderList=" + escape(document.getElementById("OrderList").value) + "&Preview=true";
        //var result = useService(postStr, "");

        document.onmouseup = null;
        document.onmousemove = null;

        try 
        {
            e.cancelBubble = true;
            e.returnValue = false;
        }
        catch (e) 
        {
            //firefox
            e.stopPropagation();
            e.returnValue = false;
        }

    }

    return false;
}



//
//when click on the portlet or click on property icon , show portlet property list
function DisplayPortletProperty(targetName,targetInstance) 
{
    //set property container url to reflect portlet property list
    try 
    {
        var ifrmae = document.getElementById("PropertyContainer");

        if (ifrmae != null) 
        {

            var currentURL = ifrmae.getAttribute("src");

            if (currentURL == "")
            {
                //parse current request url
                var siteURL = window.location.href;
                if (siteURL.indexOf("?") != -1) 
                {
                    currentURL = siteURL.substring(0, siteURL.indexOf("?"));

                    currentURL = currentURL + "?EditAdmin=true&Target=~/Component/EditPortlet.aspx" + "&parentURL=" + window.location.href + "&Preview=true";
                }
            }
            
            if(currentURL.indexOf("&PortletName")!=-1)
                currentURL = currentURL.substring(0, currentURL.indexOf("&PortletName"));

            var target = currentURL+"&PortletName=" + targetName + "&Max=true&Instance=" + targetInstance + "&PortletFrom=" + portletHost;

            //popup property window in dialogue mode for desifn view , but disabled now
            //if (layoutDesignMode == "layouttable" || layoutDesignMode == "layoutrandom")
            //    openSaveDialogue("Properties", target);
            //else
                ifrmae.setAttribute("src", target);

            var path = window.location;

            var page = currentURL.substring(currentURL.indexOf("Page="));
            page = page.substring(5, page.indexOf("&"));

            //keep cookie for one day
            setCookie("SelectedPage", page, 1, "", "", "");
            setCookie("SelectedPortletName", targetName, 1, "", "", "");
            setCookie("SelectedPortletInstance", targetInstance, 1, "", "", "");

        }
    }
    catch (e) 
    {
        window.status = e.message;
    }
}

//when click on the portlet or click on property icon , show portlet property list
function DisplayDefaultProperty(targetName, targetInstance) 
{

    //set property container url to reflect portlet property list    
    try {

        var ifrmae = document.getElementById("PropertyContainer");
        if (ifrmae != null) {

            var currentURL = ifrmae.getAttribute("src");

            if (currentURL == "") {
                //parse current request url
                var siteURL = window.location.href;
                if (siteURL.indexOf("?") != -1) {
                    currentURL = siteURL.substring(0, siteURL.indexOf("?"));

                    currentURL = currentURL + "?EditAdmin=true&Target=~/Component/EditPortlet.aspx" + "&parentURL=" + window.location.href + "&Preview=true";
                }
            }

            if (currentURL.indexOf("&PortletName") != -1)
                currentURL = currentURL.substring(0, currentURL.indexOf("&PortletName"));
                
            var target = currentURL + "&PortletName=&Max=true&Instance=" + targetInstance + "&PortletFrom=" + portletHost;

            ifrmae.setAttribute("src", target);
            ifrmae.style.display = "block";
        }
    }
    catch (e) {
        window.status = e.message;
    }
}


//
//remove portlet from site portlet list and save the selected portlet name list in a hidden field
//hostFrom :portlet from site list or page 
function RemovePortletFromSite(targetID,targetName,hostFrom) 
{
    
    if(window.confirm('Do you want to remove this ?'))
    {
        var targetObj=document.getElementById(targetID);

        var parent;

        if (targetObj.parentElement)
            parent = targetObj.parentElement;
        else
            parent = targetObj.parentNode;

        parent.removeChild(targetObj);
                      
        var removeListObj=document.getElementById('RemoveList');

        //record portlet to be removed from site portlet list
        if (hostFrom == "site") 
        {
            removeListObj.value = removeListObj.value + "|" + targetName;
        }

        //update current page portlet list and order .
        RecordPortletListOrder();
        
        if (layoutDesignMode != null) 
        {
            var siteURL = window.location.href;
            if (siteURL.indexOf("?") != -1) 
            {
                siteURL = siteURL.substring(0, siteURL.indexOf("?"));
            }
            
            var postStr="";
            if(hostFrom=="page")
            {
                postStr = siteURL + "?Target=~/Component/PortletListService.aspx&OrderList=" + escape(document.getElementById("OrderList").value) + "&Preview=true";
            }
            else if(hostFrom == "site")
            {
                postStr = siteURL + "?Target=~/Component/PortletListService.aspx&RemoveList=" + escape(document.getElementById("RemoveList").value) + "&Preview=true";
            }
            var result = useService(postStr, "");
        }
        
    }

    return false;
}



function minPortlet(PortletID,ContentBlockID,TitleBlockID, MaxImgID) 
{

    var titleBar = document.getElementById(TitleBlockID);

    //var className = titleBar.className;
    
    //get portlet  control	
    var portlet = document.getElementById(PortletID);

    //get block tag object	
    var contentBar = document.getElementById(ContentBlockID);
    //get title bar object
    var titleBar = document.getElementById(TitleBlockID);

    //get max-image button
    var maxButtonObj = document.getElementById(MaxImgID);

    {
        if (contentBar.style.visibility == "hidden") 
        {
            contentBar.style.visibility = "visible";
            event.srcElement.src = "Images/Min.gif";
            event.srcElement.title = "Min Window";
            maxButtonObj.style.visibility = "visible";

            portlet.style.height = LastHeight;
        }
        else 
        {
            contentBar.style.visibility = "hidden";

            LastHeight = portlet.style.height;
            portlet.style.height = titleBar.style.height;

            event.srcElement.src = "Images/Restore.gif";
            event.srcElement.title = "Restore Window";
            maxButtonObj.style.visibility = "hidden";
        }
    }

    //titleBar.className = className;

    window.status = "Done";
    event.cancelBubble = true;
    event.returnValue = true;
}

//
// Max portlet window
//
function maxPortlet(e,PortletID, ContentBlockID, TitleBlockID, MinImgID) 
{

    var e = (!e) ? window.event : e; //IE:Moz
    
    var titleBar = document.getElementById(TitleBlockID);

    //get portlet  control	
    var portlet = document.getElementById(PortletID);

    //get block tag object	
    var contentBar = document.getElementById(ContentBlockID);
    //get title bar object
    var titleBar = document.getElementById(TitleBlockID);

    //get max-image button
    var minButtonObj = document.getElementById(MinImgID);


    //create a element for max mode
    try 
    {
        portletContainer = window.document.getElementById("ContainerDIV");
    }
    catch (e) 
    { }

    //create container element dynamicaly if not exist
    if (portletContainer == null) 
    {
        portletContainer = window.document.createElement("DIV");

        portletContainer.innerHTML = "";
        portletContainer.id = "ContainerDIV";
        portletContainer.style.zIndex = "9999";
        portletContainer.style.position = "absolute";
        portletContainer.style.margin = 0;
        portletContainer.style.left = 10;
        portletContainer.style.top = 10;
        portletContainer.style.right = 0;
        portletContainer.style.bottom = 50;
        portletContainer.style.height = "90%";
        portletContainer.style.width = "98%";
        portletContainer.style.border = "1px solid #999999";
        //portletContainer.style.overflow = "auto";

        window.document.body.insertBefore(portletContainer,null);
     
    }


    if (portletContainer.innerHTML == "") 
    {

        //minButtonObj.style.visibility = "hidden";
        portletContainer.style.display = "block";
        //portlet.style.display = "none";

        portletContainer.innerHTML = portlet.innerHTML;

        var divObj = portletContainer.getElementsByTagName("Div");

        for (var i = 0; i < divObj.length; i++) 
        {

            if (divObj[i].id == ContentBlockID) 
            {
                LastHeight = divObj[i].style.height;
                    
                divObj[i].style.height = "100%";
                divObj[i].style.width = "100%";
                break;
            }
        }

              
        //hidden other special Objct Tag except iteself since they are always on top						
       
        var TBList = document.body.getElementsByTagName("Table");
       
        for (var t = 0; t < TBList.length; t++) 
        {
            if (TBList[t].className == "PortletLayoutContainer") 
            {
                if(PortletID!=TBList[t].id)
                    TBList[t].style.display="none";
            }
        }

        //set to max		
        e.srcElement.src = "Images/Restore.gif";    
    }
    else 
    {
                          
        portlet.innerHTML = portletContainer.innerHTML;
        portletContainer.innerHTML = "";

        portletContainer.style.display = "none";
        portlet.style.display = "block";

               
        //minButtonObj.style.visibility = "visible";
        
        var TBList = document.body.getElementsByTagName("Table");
       
        for (var t = 0; t < TBList.length; t++) 
        {
            if (TBList[t].className == "PortletLayoutContainer") 
            {
                    TBList[t].style.display="block";
            }
        }

        var divObj = portlet.getElementsByTagName("Div");

        for (var i = 0; i < divObj.length; i++) 
        {

            if (divObj[i].id == ContentBlockID) 
            {
                divObj[i].style.height = LastHeight;
            }
        }

        e.srcElement.src = "Images/full.gif";
        /*
        //show special Objct Tag when restore window			
        var obj = window.document.body.getElementsByTagName("OBJECT");
        for (var i = 0; i < obj.length; i++) {
            obj(i).style.visibility = "visible";
        }

        //show special Objct Tag when restore window			
        obj = window.document.body.getElementsByTagName("IFRAME");
        for (var i = 0; i < obj.length; i++) {
            obj(i).style.visibility = "visible";
            //obj(i).parentElement.style.filter="progid:DXImageTransform.Microsoft.Gradient(GradientType=0, StartColorStr='#86C0E4', EndColorStr='#FEFDFE')";
        }
        */
    }


    //titleBar.className = className;

    window.status = "Done";
    //event.cancelBubble = true;

}

function IconDoubleClick(SiteKey, PortletName, PageKey, Instance) 
{
    event.cancelBubble = true;

    //get portlet  control	
    /*
    var portlet = window.document.getElementById(PortletID);

    var obj = portlet.getElementsByTagName("span");
    var oldTitle = obj[1].innerText;
    obj[1].innerText = "Loading ...";
    */

    //    var obj2=portlet.getElementsByTagName("iframe");
    //    obj2[0].src="PortletConfig/Progressbar.portlet";
    //    obj2[0].width=60;
    //    obj2[0].height=15;
    //    obj2.style.visible=true;

    //ret = window.showModalDialog(SiteName + "?Target=~/Component/PortletServiceProcess.aspx&Mode=html&SiteKey=" + SiteKey + "&PortletName=" + PortletName + "&Max=true" + "&Page=" + PageKey + "&Instance=" + Instance, "", "center:yes;dialogWidth:1000px;dialogHeight:800px;resizable:yes;scroll:yes;status:no;help:no;");

    //obj[1].innerText = oldTitle;

    return;

}

var popDiv ;

function popContextMenu(menuDivID)
{
    var currentX = event.clientX || event.pageX;
    var currentY = event.clientY || event.pageY;

    var menuObj = document.getElementById(menuDivID);

    if (menuObj != null) {

        menuObj.style.position = "relative";
        menuObj.style.left = 0;
        menuObj.style.top = 0;

        menuObj.style.display = "block";
    }
    
    /*
    popDiv = document.createElement("div");
    document.body.appendChild(popDiv);

    //popDiv.innerHTML = menuObj.innerHTML;

    popDiv.style.left = currentX;
    popDiv.style.position = "absolute";
    popDiv.style.top = currentY;
    popDiv.style.width = "100";
    popDiv.style.height = "150";
    popDiv.style.background = "#eeeeee";
    popDiv.style.zIndex = "9999";

    popDiv.innerHTML = "<a href='ff'>hhhhhh</a><br>dddddd<br>ggg";

    //alert(div.outerHTML);

    event.cancelBubble = true;
    popDiv.attachEvent('onmouseout', closePoP);
    */
    
 }

 function closePoP() {
     document.body.removeChild(popDiv);    
 }

 function useService(postStr, postBody) 
 {

     try 
     {
         if (postStr != '') 
         {
             var result = "";   
             if (window.XMLHttpRequest) // FF ,chrome ,IE8
             {
           
                 var xmlHttp = new XMLHttpRequest;
                 xmlHttp.open("post", postStr, false);
                 xmlHttp.send(postBody);

                 try 
                 {
                    
                    portletHTML = xmlHttp.responseXML.getElementsByTagName("div");

                    result = portletHTML[0].firstChild.nodeValue;
                    
                 }
                 catch (e) 
                 {
                     result = e.message;
                 }
                 
                 return result;
             }
             else if (window.ActiveXObject) //older IE ?
             {
                 var xmlDoc = new ActiveXObject("MSXML.DOMDocument");
                 xmlDoc.async = false;

                 var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                 xmlHttp.open("post", postStr, false);
                 xmlHttp.send(postBody);
                 
                 xmlDoc.load(xmlHttp.responseXml);

                 var portletHTML = "";
                 if (xmlDoc.parseError.errorCode == 0)		//parse OK
                 {

                     portletHTML = xmlDoc.documentElement.selectSingleNode("//div").text;

                 }

                 delete xmlDoc;
                 delete xmlHttp;

                 return portletHTML;

             }
         }
         else 
         {
             return "";
         }
     }
     catch (e) 
     {
         return "";
     }
 }

 /*=============================page context menu action================================*/
 //page delete command from page tree
 function PageDeleteCommand(currentNodeID) 
 {

     var result = PageActionCommand(currentNodeID, "delete");

     if (result != "") 
     {
         window.location = result;
     }

     return false;
 }

 //page copy command from page tree
 function PageCopyCommand(currentNodeID) 
 {

     selectedPageName = PageActionCommand(currentNodeID, "copy");

     //document.getElementById("selectedPageName").value = selectedPageName;

     return false;
 }
 
 function PageEditCommand(elem) 
 {
     //result = PageActionCommand(currentNodeID, "edit");

     return true;
 }

 //page paste command from page tree
 function PagePasteCommand(currentNodeID) 
 {

     var result = PageActionCommand(currentNodeID, "paste");
     
     if (result != "") 
     {
         window.location = result;
     }

     return false;
 }

 //page rollback command from page tree
 function PageRevertCommand(currentNodeID) {

     var result = PageActionCommand(currentNodeID, "revert");

     if (result != "") {
         window.location = result;
     }

     return false;
 }

 function PageActionCommand(currentNodeID,action) 
 {

    var result="";

    try 
    {

         var nodeValue = eval(currentNodeID + ".getSelectedItem().parentNode.getAttribute('treeNodeValue')");

         if (nodeValue != null) 
         {
            
             //parse current request url
             var siteURL = window.location.href;
             if (siteURL.indexOf("?") != -1) {
                 siteURL = siteURL.substring(0, siteURL.indexOf("?"));
             }
         }
                  
         var postStr = siteURL + "?Target=~/Component/PageTreeService.aspx&Mode=xml&ActionMode=" + action + "&PageName=" + nodeValue + "&EditMode=" + layoutDesignMode;
         
         result = useService(postStr, "");
         
    }
    catch (e) 
    {
    }

    return result;
 }

 /*=============================template context menu action================================*/
 //page delete command from page tree
 function TemplateDeleteCommand(currentNodeID) 
 {

     var result = TemplateActionCommand(currentNodeID, "delete");

     if (result != "") 
     {
         window.location = result;
     }

     return false;
 }

 //page copy command from page tree
 function TemplateCopyCommand(currentNodeID) 
 {

     TemplateActionCommand(currentNodeID, "copy");

     return false;
 }
 
 function TemplateEditCommand(elem) 
 {
     //result = PageActionCommand(currentNodeID, "edit");

     return true;
 }

 //page paste command from page tree
 function TemplatePasteCommand(currentNodeID) 
 {

     var result = TemplateActionCommand(currentNodeID, "paste");
     
     if (result != "") 
     {
         window.location = result;
     }

     return false;
 }

 function TemplateActionCommand(currentNodeID,action) 
 {

    var result="";

    try 
    {

         var nodeValue = eval(currentNodeID + ".getSelectedItem().parentNode.getAttribute('treeNodeValue')");

         if (nodeValue != null) 
         {
            
             //parse current request url
             var siteURL = window.location.href;
             if (siteURL.indexOf("?") != -1) {
                 siteURL = siteURL.substring(0, siteURL.indexOf("?"));
             }
         }

         var postStr = siteURL + "?Target=~/Component/TemplateTreeService.aspx&Mode=xml&ActionMode=" + action + "&PageName=" + nodeValue + "&EditMode=" + layoutDesignMode;
         
         result = useService(postStr, "");
         
    }
    catch (e) 
    {
    }

    return result;
}

/*=============================site context menu action================================*/
//page delete command from page tree
function SiteDeleteCommand(currentNodeID) {

    var result = SiteActionCommand(currentNodeID, "delete");

    if (result != "") {
        window.location = result;
    }

    return false;
}

//page copy command from page tree
function SiteCopyCommand(currentNodeID) {

    SiteActionCommand(currentNodeID, "copy");

    return false;
}

function SiteEditCommand(elem) {
    //result = PageActionCommand(currentNodeID, "edit");

    return true;
}

//page paste command from page tree
function SitePasteCommand(currentNodeID) {

    var result = SiteActionCommand(currentNodeID, "paste");

    if (result != "") {
        window.location = result;
    }

    return false;
}

function SiteActionCommand(currentNodeID, action) {

    var result = "";

    try {

        var nodeValue = eval(currentNodeID + ".getSelectedItem().parentNode.getAttribute('treeNodeValue')");

        if (nodeValue != null) {

            //parse current request url
            var siteURL = window.location.href;
            if (siteURL.indexOf("?") != -1) {
                siteURL = siteURL.substring(0, siteURL.indexOf("?"));
            }
        }

        var postStr = siteURL + "?Target=~/Component/SiteListService.aspx&Mode=xml&ActionMode=" + action + "&PageName=" + nodeValue + "&EditMode=" + layoutDesignMode;

        result = useService(postStr, "");

    }
    catch (e) {
    }

    return result;
}
 