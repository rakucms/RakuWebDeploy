﻿//javascript for admin mode

var originalLayourWidth = "";

// tab view control 
function ChooseTab(index) {

    var target = document.getElementsByName("Tab-Control");

    var obj = document.getElementsByName("Tab-Container");

    for (var i = 0; i < target.length; i++) {
        if (i == index) {

            try {
                target[i].className = "SelectedTab";
                obj[i].style.display = "block";
            }
            catch (e) { }
        }
        else {

            try {
                target[i].className = "UnSelectedTab";
                obj[i].style.display = "none";
            }
            catch (e) { }
        }
    }

    return;
}

//open a modal dialogue
function openDialogue(ptitle, purl) {

    var pWidth = screen.width - 330;

    var pHeight = screen.height - 260;

    //openModalDialogue(ptitle, purl, pWidth, pHeight);

    openFrameDialogue(ptitle, purl, pWidth, pHeight); 

}

//open a modal dialogue
function openModalDialogue(ptitle, purl, pwidth, pheight) {
   
    try {
        if (pwidth == "")
            pwidth = screen.width - 330;

        if (pheight == "")
            pheight = screen.height - 200;

        top.$('#CommonDialogue').openWidow(
        {
            url: purl,
            modal: true,
            frame: false,
            width: pwidth,
            height: pheight,
            title: ptitle
        });
    }
    catch (e) { }

    return false;

}

//Display a dialogue in iframe
function openFrameDialogue(ptitle, purl, pwidth, pheight) {

    try {
        
        if (pwidth == "")
            pwidth = screen.width - 330;

        if (pheight == "")
            pheight = screen.height - 150;
        
        top.$('#CommonDialogue').openWidow(
        {
            modal: true,
            title: ptitle,
            width: pwidth,
            frame: true,
            height: pheight, 
            url: purl,
            buttons: "close"

        });

    }
    catch (e) {
    }

    return false;
}

//close dialogue by iframe 
function closeDialogueEditor() {

    try {

        top.$('#CommonDialogue').openWidow("close");
        
        var target = window.top.document.getElementById("Editor3frame");

        var editorObject;

        if (target.parentElement != null)
            editorObject = target.parentElement;    //IE ,Chrome
        else (target.parentNode != null)
        editorObject = target.parentNode;   //firefox

        editorObject.style.display = "none";
        window.parent.document.body.removeChild(editorObject);
    }
    catch (e) {
    }
}

//open a modal dialogue
function openSaveDialogue(ptitle, purl) {

    var dlg;

    try {

        var editorFrame = window.parent.document.getElementById("BottomPane");
        if (editorFrame != null)
            editorFrame.innerHTML = "";
    }
    catch (e)
    { }

    var propertyDIV = window.parent.document.getElementById("PropertyContainer")

    if (propertyDIV == null) {
        dlg = window.parent.document.createElement("iframe");
        dlg.id = "PropertyContainer";
        dlg.width = "100%";
        dlg.height = 460;
        dlg.setAttribute("frameborder", "0");
        dlg.frameBorder = 0;
        dlg.scrolling = "no";
        dlg.src = purl;
        window.parent.document.body.insertBefore(dlg, null); //second parameter for firefox
        //window.document.body.appendChild(dlg, null); //second parameter for firefox
    }
    else {
        propertyDIV.setAttribute("frameborder", "0");
        propertyDIV.frameBorder = 0;
        propertyDIV.src = purl;
    }

    //var pHeight;

    //var pWidth;

    var pWidth = 330;

    var pHeight = 450;

    parent.$('#PropertyContainer').dialog(
    {
            showType: 'fade', destroyOnClose: false, modal: false, width: pWidth, height: pHeight, title: ptitle, closeText: "×"
    });

}

//toggle right pane display or hide
function ControlRightPane() {

    if (RightControlPanel.style.display == 'none')
        RightControlPanel.style.display = 'block';

    if (RightControlPanel.style.width == '0px' || RightControlPanel.style.width == '0pt') {
        RightControlPanel.style.width = TopPane.style.width;
        //LayoutDIV.style.width = originalLayourWidth;

        document.getElementById("rightPanelImage").setAttribute("src", "../Images/maximize.gif");

    }
    else {
        RightControlPanel.style.width = "0px";

        originalLayourWidth = LayoutDIV.style.width;
        //LayoutDIV.style.width = "100%";

        document.getElementById("rightPanelImage").setAttribute("src", "../Images/minimize.gif");
    }
}


//toggle left pane display or hide
function ControlLeftPane() {
    if (portletlistManager_Panel.style.display == 'block') 
    {
        portletlistManager_Panel.style.display = 'none';
        document.getElementById("leftPanelImage").setAttribute("src", "../Images/maximize.gif");

        setCookie("LeftPanel", "none", 0, "", "", ""); 
    }
    else {
        portletlistManager_Panel.style.display = 'block';
        document.getElementById("leftPanelImage").setAttribute("src", "../Images/minimize.gif");

        setCookie("LeftPanel", "block", 0, "", "", ""); 
    }

}

function ToggleLeftPane(status) {

    portletlistManager_Panel.style.display = status;
    if (status == 'block') {
        document.getElementById("leftPanelImage").setAttribute("src", "../Images/maximize.gif");
    }
    else 
    {
        document.getElementById("leftPanelImage").setAttribute("src", "../Images/minimize.gif");
    }
}

//open editor window
function openEditor(url, title) {

    try {
        var targetFrame = window.parent.document.getElementById("Editorframe");
        if (targetFrame == null) {
            dlg = window.top.document.createElement("iframe");
            dlg.id = "Editorframe";
            dlg.style.position = "absolute";
            dlg.style.top = 60;
            dlg.style.left = 80;
            dlg.width = "90%";
            dlg.height = "90%";
            dlg.src = url;
            dlg.frameBorder = 0;
            dlg.style.zIndex = 99999;
            window.top.document.body.style.background = "#EBEBEB";
            //window.parent.document.body.style.background="dddddd";

            window.top.document.body.insertBefore(dlg, null); //second parameter for firefox

            return false;
        }
        else {
            targetFrame.style.display = "block";
            targetFrame.setAttribute("src", url);
        }

        var targetLayout = window.parent.document.getElementById('LayoutDIV');
        targetLayout.style.display = "none";

        //make main container full 100% to overrite the css setting
        var masterContainer = window.parent.document.getElementById('ContentContainer');
        masterContainer.style.width = "100%";

        var targetWindow = window.parent.document.getElementById("editorPanel");
        targetWindow.style.display = "block";

        var titleBar = window.parent.document.getElementById("editorTitle");
        //firefox,chrome
        titleBar.textContent = title;
        //IE
        titleBar.innerText = title;

    }
    catch (e) {
    }

    return false;

}


//close editor window
function closeEditor(confirmation) {
    try {

        if (confirmation == "false")
            if (window.confirm("Do you like to close ?") == false)
                return;

        var targetFrame = window.top.document.getElementById("Editorframe");
        targetFrame.style.display = "none";

        var targetLayout = window.top.document.getElementById('LayoutDIV');
        targetLayout.style.display = 'block';

        var targetWindow = window.top.document.getElementById("editorPanel");
        targetWindow.style.display = "none";

        targetFrame.setAttribute("src", "");

        //save property value by ajax call
        /*
        {
        var postStr = document.forms[0].requestURL.value;
        postStr = postStr + "&PropertyValue=" + retValue;            
        var result = useService(postStr, "");            
        }*/
    }
    catch (e) { }

}

//close editor and return selcted content
function saveEditor(retValue) {

    try {

        var targetFrame = window.parent.document.getElementById("Editorframe");
        targetFrame.style.display = "none";

        var targetLayout = window.parent.document.getElementById('LayoutDIV');
        targetLayout.style.display = 'block';

        sourceObj.value = retValue;

        //save property value by ajax call
        PostProtletProperty(retValue);
    }
    catch (e) { alert(e.message); }

}


function getCookie( name ) 
{
    var start = document.cookie.indexOf( name + "=" );
    var len = start + name.length + 1;
    if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) ) {
        return null;
    }
    if ( start == -1 ) return null;
    var end = document.cookie.indexOf( ';', len );
    if ( end == -1 ) end = document.cookie.length;
    return unescape( document.cookie.substring( len, end ) );
}
 
function setCookie( name, value, expires, path, domain, secure ) 
{
    var today = new Date();
    today.setTime( today.getTime() );
    if ( expires ) {
        expires = expires * 1000 * 60 * 60 * 24;
    }

    var expires_date = new Date( today.getTime() + (expires) );
    document.cookie = name+'='+escape( value ) +
        ( ( expires ) ? ';expires='+expires_date.toGMTString() : '' ) + //expires.toGMTString()
        ( ( path ) ? ';path=' + path : '' ) +
        ( ( domain ) ? ';domain=' + domain : '' ) +
        ((secure) ? ';secure' : '');

}

function deleteCookie(name, path, domain) 
{
    if (getCookie(name)) document.cookie = name + '=' +
            ((path) ? ';path=' + path : '') +
            ((domain) ? ';domain=' + domain : '') +
            ';expires=Thu, 01-Jan-1970 00:00:01 GMT';
}

function getIFrameDocument(aID) {
    try {
        // if contentDocument exists, W3C compliant (Mozilla)
        if (window.parent.document.getElementById(aID).contentDocument) {
            return window.parent.document.getElementById(aID).contentDocument;
        } else {
            // IE
            return window.parent.document.frames[aID].document;
        }
    }
    catch (e) {
    }
}

function getCurrentIFrameDocument(aID) {
    // if contentDocument exists, W3C compliant (Mozilla)
    if (window.document.getElementById(aID).contentDocument) {
        return window.document.getElementById(aID).contentDocument;
    } else {
        // IE
        return window.document.frames[aID].document;
    }
}

//open a new tab window

function addTab(title, url) {
    $('#EditorWindow').tabs('add',
     {
         title: title,
         content: '<iframe scrolling="auto" frameborder="0" style="width:100%;height:100%;"' + ' src=' + url + '></iframe>',
         closable: true,
         height: '100%'
     });
}


//remove control value
function RemoveControlValue(clientID) {
    var selectControl = document.getElementById(clientID);
    selectControl.value = "";
}

/*
$(function() 
{
var w = $(window);
$('#EditorPanel').height(w.height());
$('#EditorWindow').height(w.height());
$('#EditorWindow').tabs();
});
*/


(function ($) {

     $.fn.openWidow = function (options) {

        var settings = {
            zIndex:99999,
            width: 400,
            height: 590,
            modal: true,
            url: "",
            frame: true
            
        };
        if (options) {
            $.extend(settings, options);
        }

        // Dialog            
        $("#CommonDialogue").dialog({
            autoOpen: false,
            zIndex: settings.zIndex,
            title: settings.title,
            width: settings.width,
            height: settings.height,
            modal: settings.modal,
            //bgiframe: true,
            frame: settings.frame,
            url:settings.url,
            closeText: "×",
            
            classes: {
                //"ui-dialog-titlebar": "25px"
            },
    
            resizeStop: function () {

                //if (settings.frame == true) 
                {
                    //$("#dialogFrame").css("width", parseInt($(this).css("width")) - 5);
                    //$("#dialogFrame").css("height", parseInt($(this).css("height")) - 5);
                 }
             },

            close: function () {

                try {
                    f (settings.frame == true) 
                    {
                        //$("#dialogFrame").remove();
                    }

                }
                catch (e) {
                    //document.write(e.message);
                }
            },


            open: function () {
                if (settings.frame == true) {
                    $("#CommonDialogue").html('<iframe src="' + settings.url + '" frameborder="0" id="dialogFrame" style="overflow:hidden;width:99%;height:99%;"></iframe>');
                    //$("#dialogFrame").css("height", parseInt($(this).css("height")) - 10);
                    //$("#dialogFrame").css("width", parseInt($(this).css("width")) - 10);
                }
                else {

                    $.ajax({
                        url: settings.url,
                        success: function (data) {
                            
                            var str = "";
                            var result = $(data).find('#PortletContainer').html(); 

                            //alocate client script to render mvc control 
                            var begin = data.indexOf("<script type=\"text/javascript\">");
                            if (begin != -1) {
                                str = data.substring(begin);
                                var last = str.indexOf("</script>");
                                if (last != -1) 
                                    str = str.substring(0, last + 9);
                            }
                            //return result html and script if any
                            $("#CommonDialogue").html(result + str); //alert($("#CommonDialogue").parent().html());
                        }
                    });
                }
            }
        });

        $("#CommonDialogue").dialog("open");
        
        return this;
    };
})(jQuery);

