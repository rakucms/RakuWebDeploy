/*
click event handing for portlet container tab
*/

var ListContentID;
var PortletSearch;

function expandCollapseList(contentID,searchkey)
{	
    ListContentID=contentID;
    PortletSearch=searchkey;
    
    var e = (!e) ? window.event : e; //IE:Moz
    	  
	//e.cancelBubble=true;
	
	if (ListContentID!="" && ListContentID!=null)
	{	
        try {

            if ($(e.srcElement).attr("class") == "xpanel") {

                $("#portletlistManager_Panel").find(".PortLetContainer").parent().css("display", "none");
                $(".xpanelSelected").attr("class", "xpanel");

                $(e.srcElement).attr("class", "xpanelSelected");
                $('#' + ListContentID).css("display", "block");
            }
            else {
                $(e.srcElement).attr("class", "xpanel");
                $('#' + ListContentID).css("display", "none");
            }

            window.status="Widget List Loaded";

		}
		catch(e)
		{
			window.status=e.description;
			return;
		}														
	}						
}

//load saved status 
try
{

    //in not search mode , hide or display content list by last selection otherwise display as default
    //alert(PortletSearch)  ;
  
    /*
    {
        var lastObj=document.getElementById('Portlet_Selection');
        var lastContent=document.getElementById(ListContentID);
        
        lastObj.load("PortlistStatus");

        var objstatus=lastObj.getAttribute(ListContentID).split("|");
        
        lastContent.style.display=objstatus[0];
        
        var lastControl=document.getElementById(objstatus[1]);
        
          
        if(lastContent.style.display=="none")
            lastControl.className="xpanel";
            
        else
            lastControl.className="xpanelSelected";
            
     }
    */
}
catch(e)
{
}
