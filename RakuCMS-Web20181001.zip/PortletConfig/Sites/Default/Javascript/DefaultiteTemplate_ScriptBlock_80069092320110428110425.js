[PortletEditable("Content", "true")]
        [PortletControlType("dropdownlist", "post|get|session|cookie")]
        public string Parameter
        {
            get
            {
                return this.dbParameter;
            }
            set
            {
                this.dbParameter = value;
            }
        }