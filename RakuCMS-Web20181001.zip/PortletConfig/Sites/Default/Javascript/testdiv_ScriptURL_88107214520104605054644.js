TypeLibrary/JSLibrary/JQuery/js/jquery-1.3.2.min.js
Component/js/MainScript.js