TypeLibrary/JSLibrary/JQuery/js/new-jquery.min.js
Component/js/MainScript.js