$.ajax(
        {
        type: "POST",
        async:false,
        url: "/Default/Home/0a9854cd-2e23-44ce-9354-2ac733f56351/42690108620124923114902?Mode=data&Max=true",
        data: "{sourceCode:'9999999999999999'}",
        //data: "sourceCode=99999999999999999}",
          
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) 
        {
          //alert("OK");
        },
        error: function (result, status) 
        {
        	
        	//alert("Fail");
                
        }
        });