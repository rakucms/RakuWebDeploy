#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# enable debugging
import cgitb
cgitb.enable()

print "Content-Type: text/plain;charset=utf-8"
print

print "<p>Hello WORLD!!XX XXXXXX!!!!1>"
print "<p>Hello hhhhWorld!</p>"
print "<p>Hello hhhhWorld!</p>"