#!/usr/bin/env python3
print("Content-type: text/html\n")
print("<html><body>Python is awesome</body></html>")